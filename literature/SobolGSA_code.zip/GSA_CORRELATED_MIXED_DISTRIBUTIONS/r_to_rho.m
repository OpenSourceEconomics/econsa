function rho = r_to_rho( typedistr1, typedistr2, mu1, sigma1, mu2, sigma2, r )
%r_to_rho is the inverse of rho_to_r and computes the Pearson correlation 
%coefficient of two normal random variables corresponding to two correlated
%random variables distributed as typedistr1 and typedistr2 with a correlation
%coefficient r.

%Distributions covered: uniform, triangular, normal, loguniform, lognormal,
%and exponential

% Created by S. Kucherenko, A. Klimenko
%Imperial College London, London, SW7 2AZ, UK
% Latest revision: 11 Jan, 2015


n = size(r,2);
rho = zeros(1,n);

options = optimset('TolX', 1E-5);

%The function returns the solution of the equation |r - rho_to_r(rho)| = 0.
%The solution is unique owing to the monotonicity of the dependences rho(r)
%and r(rho).
for i=1:n
    if abs(r(i)) < 0.95,
        fn = @(x) ( r(i) - rho_to_r( typedistr1, typedistr2, mu1, sigma1, mu2, sigma2, x ) );
        rho(i) = fzero(fn, r(i), options);
    else
        %When |r| is close to 1 a minimisation problem is solved on the
        %domain [-1, 1] since the search in fzero cannot be restricted to
        %this domain which may lead to wrong or complex-valued solutions.
        fn = @(x) abs( r(i) - rho_to_r( typedistr1, typedistr2, mu1, sigma1, mu2, sigma2, x ) );
        rho(i) = fminbnd(fn, -1, 1, options);
    end
end

end


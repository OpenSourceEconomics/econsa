function r = rho_to_r( typedistr1, typedistr2, mu1, sigma1, mu2, sigma2, rho )
%rho_to_r computes the Pearson correlation coefficient of two random
%variables distributed as typedistr1 and typedistr2 given that the
%corresponding standard normal variables related to the typedistr1,2 variables
%through the Nataf model are correlated with a coefficient rho.

%Distributions covered: uniform, triangular, normal, loguniform, lognormal,
%and exponential

% Created by S. Kucherenko, A. Klimenko
%Imperial College London, London, SW7 2AZ, UK
% Latest revision: 11 Jan, 2015

n = size(rho,2);

%Assign the inverse CDFs as well as expected values and variances (as required)
%depending on the distribution type

%First random variable:
if strcmp(typedistr1,'UNIF'),
    %Parameters mu and sigma are treated here as a and b of the uniform
    %disribution: a <= X <= b
     a = mu1;
     b = sigma1;

    %Compute mu and sigma
    mu1 = (a+b)/2;
    sigma1 = (b-a)/sqrt(12);

    InvCDF1 = @(x) a + (b - a)*x;
    
elseif strcmp(typedistr1,'TRIANG'),
    %Parameters mu and sigma are treated here as a and b of the symmetrical
    %triangular disribution: a <= X <= b
    a = mu1;
    b = sigma1;
    %Compute the limits of the support of the random variable. For the triangular distribution mu = (a+b)/2, sigma = (b-a)/sqrt(24) 
    mu1 = (a+b)/2;
    sigma1 = (b-a)/sqrt(24);

    InvCDF1 = @(x) ((a + (b-a)*sqrt(x./2)).*(x >= 0).*(x < 0.5) + (b - (b-a)*sqrt((1-x)/2)).*(x >= 0.5).*(x <= 1)); %general form
    
elseif strcmp(typedistr1,'NORM'),
    InvCDF1 = @(x) norminv(x, mu1, sigma1);
    
elseif strcmp(typedistr1,'LOGUNIF'),
    %Parameters mu and sigma are treated here as a and b of the loguniform
    %disribution Y = ln(X), a <= X <= b
    a = mu1;
    b = sigma1;
    mu1 = (b-a)/(log(b) - log(a));
    sigma1 = sqrt(0.5*(b^2 - a^2)/(log(b) - log(a)) - mu1^2);

    InvCDF1 = @(x) a*(b./a).^x;
    
elseif strcmp(typedistr1,'LOGNORM'),
    %Compute lambda and dzeta - the mean and STD of the associated normal
    %distribution:
    CV = sigma1/mu1;
    lambda = log(mu1/(sqrt(1+CV^2)));
    dzeta = sqrt(log(1+CV^2));

    InvCDF1 = @(x) logninv(x, lambda, dzeta);
    
elseif strcmp(typedistr1, 'EXPO'),
    InvCDF1 = @(x) expinv(x, mu1);
    
end

%Second random variable:
if strcmp(typedistr2,'UNIF'),
    a = mu2;
    b = sigma2;
    mu2 = (a+b)/2;
    sigma2 = (b-a)/sqrt(12);
    
    InvCDF2 = @(x) a + (b - a)*x;
    
elseif strcmp(typedistr2,'TRIANG'),
    a = mu2;
    b = sigma2;
    mu2 = (a+b)/2;
    sigma2 = (b-a)/sqrt(24);

    InvCDF2 = @(x) ((a + (b-a)*sqrt(x./2)).*(x >= 0).*(x < 0.5) + (b - (b-a)*sqrt((1-x)/2)).*(x >= 0.5).*(x <= 1)); %general form
    
elseif strcmp(typedistr2,'NORM'),
    InvCDF2 = @(x) norminv(x, mu2, sigma2);
    
elseif strcmp(typedistr2,'LOGUNIF'),   
    a = mu2;
    b = sigma2;
    mu2 = (b-a)/(log(b) - log(a));
    sigma2 = sqrt(0.5*(b^2 - a^2)/(log(b) - log(a)) - mu2^2);
    
    InvCDF2 = @(x) a*(b./a).^x;
    
elseif strcmp(typedistr2,'LOGNORM'),
    CV = sigma2/mu2;
    lambda = log(mu2/(sqrt(1+CV^2)));
    dzeta = sqrt(log(1+CV^2));
    
    InvCDF2 = @(x) logninv(x, lambda, dzeta);
    
elseif strcmp(typedistr2, 'EXPO'),
    InvCDF2 = @(x) expinv(x, mu2);
    
end

%PDF of the 2D standard normal distribution. Correlation between the normal
%variables has been removed through a coordinate transformation.
normpdf2 = @(x, y) exp(-(x.^2 + y.^2)./2.0)./(2.0*pi);

%Integration limit. Integration is performed in a square region symmetrical
%w.r.t. the origin.
xmax = 5.0;

%Initialise the output array
r = zeros(1,n);

%Perform the integration for every value of rho and compute the correlation
%coefficient
for i=1:n
    %redefine the integrand at each iteration with a new rho value
    integrand = @(x, y) InvCDF1(normcdf(x.*sqrt(1-rho(i)^2) + rho(i)*y,0,1)).*InvCDF2(normcdf(y,0,1)).*normpdf2(x, y);
    r(i) = (integral2(integrand,-xmax,xmax,-xmax,xmax) - mu1*mu2)/(sigma1*sigma2);
end

end


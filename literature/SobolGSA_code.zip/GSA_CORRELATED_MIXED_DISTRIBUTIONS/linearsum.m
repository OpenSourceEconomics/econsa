function y=linearsum(x)

y=sum(x);

return

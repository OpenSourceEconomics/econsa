function y=ishigami(x)

%x=2*pi*x-pi;
y=sin(x(1))+7*sin(x(2))^2+0.1*sin(x(1))*x(3)^4;
return

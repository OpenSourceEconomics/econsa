function COR_N = cor_matr_Arb_to_N(COR,typedistr,mu,sigma)
%cor_matr_Arb_to_N converts the correlation matrix COR of a vector of
%random variables defined by typedistr, mu and sigma into the corresponding
%correlation matrix of normally distributed variables linked to the former
%ones through the Nataf model.

% Created by S. Kucherenko, A. Klimenko
%Imperial College London, London, SW7 2AZ, UK
% Latest revision: 11 Jan, 2015


n = size(COR,1);

%Create a unit matrix
COR_N = eye(n);

vname = @(x) inputname(1);

for i=1:n-1
    for j=i+1:n
        %check the feasibility of the COR(i,j) value
        r = COR(i,j);
        r_max = rho_to_r(typedistr(i), typedistr(j), mu(i), sigma(i), mu(j), sigma(j), 1.0);
        r_min = rho_to_r(typedistr(i), typedistr(j), mu(i), sigma(i), mu(j), sigma(j), -1.0);
        if r > r_max,
            warning('The value %.4f of %s(%d, %d) is not feasible. It has been replaced with the maximum feasible value %0.4f', r, vname(COR), i, j, r_max);
            COR(i,j) = r_max;
            COR_N(i,j) = 1.0;
        elseif r < r_min,
            COR(i,j) = r_min;
            COR_N(i,j) = -1.0;
            warning('The value %.4f of %s(%d, %d) is not feasible. It has been replaced with the minimum feasible value %0.4f', r, vname(COR), i, j, r_min);
        else
            COR_N(i,j) = r_to_rho(typedistr(i), typedistr(j), mu(i), sigma(i), mu(j), sigma(j), r);
        end
        
        COR_N(j,i) = COR_N(i,j);
    end    
end       

end


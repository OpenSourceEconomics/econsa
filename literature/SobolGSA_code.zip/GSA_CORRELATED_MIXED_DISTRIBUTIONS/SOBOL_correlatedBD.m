function [S ST] = SOBOL_correlatedBD(k,N,typesampling,typedistr,mu,sigma,a,b,COR,model)

%Sequential estimations of first order and total effects with
%correlated input
%Total cost = N(k+2)
% k = n of inputs
% N = number of samples
% typesampling = 'Sobol' or 'Random'
% typedistr = type of distribution for input factors ('NORM', 'UNIF', 'EXPO', 'LOGNORM', 'TRIANG', 'LOGUNIF')
% mu = mean vector only for 'NORM'
% sigma= standard deviation vector only for 'NORM'
% for 'LOGNORM', 'EXPO'
% a = mean vector 
% b = standard deviation vector
% for 'UNIF', 'TRIANG', 'LOGUNIF'
% a = left 
% b = right boundary
% COR correlation matrix
% model = string with type of model 'ishigami','sum'

% S = matrix (N,k) of first order indices
% ST = matrix (N,k) of total indices
%parameters for test model

% Created by S. Kucherenko,  A. Klimenko, S. Tarantola
% Latest revision: 15 October, 2015


%vector of model output used to calculate output variance
Dsum=0;
fsum=0;
Vsum=zeros(1,k);
Vzsum=zeros(1,k);
VTsum=zeros(1,k);

%define matrix m used to compute conditional variances
for i=1:k
    m(i,1:k-1)=[1:i-1,i+1:k] ;
end

% i=1;

CONST = zeros(1,k);
for i=1:k
    if strcmp(typedistr(i),'NORM'),
        CONST(i) = 1;
    end    
end
        

% for 'NORM', 'LOGNORM', 'EXPO'
% a = mean vector 
% b = standard deviation vector

for i=1:k
    if strcmp(typedistr(i),'NORM') || strcmp(typedistr(i),'LOGNORM') || strcmp(typedistr(i),'EXP'),
        a(i)=mu(i) ;
        b(i)=sigma(i);
    end 
end


% define new correlation matrix with Nataf Model
COR_N = cor_matr_Arb_to_N(COR,typedistr,mu,sigma)

% define covariance matrix
for i=1:k
    for j=1:k
        if strcmp(typedistr(i),'NORM'),
            COV(i,j)=COR_N(i,j)*sigma(i)*sigma(j);
        else
            COV(i,j)=COR_N(i,j);
        end
    end
end

A=chol(COV);
% Preparation of covariance matrix conditional on y as in formula (3.5)
for j=1:k,
    notj = m(j,:);
    SIGzc = COV(notj,notj) - COV(notj,j)*inv(COV(j,j))*COV(j,notj);
    Azc(:,:,j)=chol(SIGzc);
end

% Preparation of covariance matrix conditional on z as in formula (3.5)
for j=1:k,
    notj = m(j,:);
    SIGyc = COV(j,j) - COV(j,notj)*inv(COV(notj,notj))*COV(notj,j);
    Ayc(:,:,j)=chol(SIGyc);
end

for i=2:N
    %generation of uniform samples in (0;1)
    if strcmp(typesampling,'Sobol'),
        T = LPTAU51(i,2*k);
    elseif strcmp(typesampling,'Random'),
        T = rand(1,2*k);
    end
    
    %Generation of two uniform vectors
    W=T(1:k);
    Wp=T(k+1:2*k);
    
    %Generation of two independent normal vectors
    u = norminv(W,0,1);
    up = norminv(Wp,0,1);
    
    %Generation of two correlated normal vectors
    x=u*A+times(CONST,mu);
    xp=up*A+times(CONST, mu);
    
    %Generation of two correlated vectors for a given distribution
    x_bar=Tranformation_required_distribution(k,x,typedistr,a,b);
    xp_bar=Tranformation_required_distribution(k,xp,typedistr,a,b);
    
% Get values of the output for a given model for x, x'
    if strcmp(model,'ishigami'),
        y=ishigami(x_bar);
        yp=ishigami(xp_bar);
    elseif strcmp(model,'portfolio'),
        y=portfolio(x_bar);
        yp=portfolio(xp_bar);
    elseif strcmp(model,'linearsum'),
        y=linearsum(x_bar);
        yp=linearsum(xp_bar);
    end
     
    ym=(y+yp)/2;
    
    fsum=fsum+ym;
    f0=fsum/i; %mean value after i iterations
    
    Dsum=Dsum+(y-f0)*(y+f0); %output variance after i iterations
    D(i)=Dsum/i;
    
    for j=1:k,
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %ESTIMATION OF FIRST ORDER INDICES Using formula (2.8)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %sampling y' as a part of x'
        y_p(j)=xp(j);
        
        %sampling from p(y',z_hat|y')
        notj = m(j,:);
        MUzc = times(CONST(notj),mu(notj)) + COV(j,notj)*inv(COV(j,j))*(y_p(j)-CONST(j) *mu(j));

        z_hat(notj)=u(notj)*Azc(:,:,j)+MUzc;

        % combine (y',zhat )
        Ab(j)=y_p(j);
        Ab(notj)=z_hat(notj);

        % transformation from normal to a given distribution using copula
        Ab_bar=Tranformation_required_distribution(k,Ab,typedistr,a,b);
      
% Get values of the output for a given model for (y', z_hat)
        if strcmp(model,'ishigami'),
            yAb=ishigami(Ab_bar);
        elseif strcmp(model,'portfolio'),
            yAb=portfolio(Ab_bar);
        elseif strcmp(model,'linearsum'),
            yAb=linearsum(Ab_bar);
        end
        
%  MC estimator - formula (5.6) from formula (2.8)        
        Vsum(j)=Vsum(j)+yp*(yAb-y); 
        S(i,j)=Vsum(j)./(i*D(i));
 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %ESTIMATION OF TOTAL INDICES Using formula (2.11)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %sampling z as a part of x
        z(notj)=x(notj);
        
        %sampling from p(y',z|z)
        MUyc = CONST(j)*mu(j) + COV(j,notj)*inv(COV(notj,notj))*(z(notj)-times(CONST(notj),mu(notj)))';
        
        ycz(j)=up(j)*Ayc(:,:,j)+MUyc;
        
        %composing (y',z | z)
        Aby(j)=ycz(j);
        Aby(notj)=z(notj);
        
        % transformation from normal to a given distribution using copula
        Aby_bar=Tranformation_required_distribution(k,Aby,typedistr,a,b);
        
% Get values of the output for a given model for (y'_hat, z)        
        if strcmp(model,'ishigami'),
            yAby=ishigami(Aby_bar);
        elseif strcmp(model,'portfolio'),
            yAby=portfolio(Aby_bar);
        elseif strcmp(model,'linearsum'),
            yAby=linearsum(Aby_bar);
        end
        
        VTsum(j)=VTsum(j)+((y-yAby)^2)/2;
        ST(i,j)=VTsum(j)./(i*D(i));

    end %j=1:k
    
end %i=1,N
return



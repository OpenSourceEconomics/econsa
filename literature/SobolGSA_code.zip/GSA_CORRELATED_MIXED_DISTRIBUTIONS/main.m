% Created by S. Kucherenko,  A. Klimenko, S. Tarantola
% Latest revision: 15 October, 2015
% Imperial College London, London, SW7 2AZ, UK

clc
clear all
tic;
% % % % % Correlation Matrix
ro = 0.0;

%model='ishigami';
COR=[1	0	ro; ...
    0	1	0 ;	...
    ro  0	1]

%model='linearsum';
% COR=[1	0	0; ...
%     0	1	ro ;	...
%     0  ro	1]

% % % % %  Dimension, Number of simulation, model, sampling method
k=3;
N=2^10;

% % % % % Distribution, Mean vector, Standard deviation vector

% typedistr={ 'UNIF'  'NORM'  'LOGNORM'} 
typedistr={ 'UNIF'  'UNIF' 'UNIF'} 
%typedistr={ 'NORM' 'NORM' 'NORM'} 

% mu = mean vector only for 'NORM'
% sigma= standard deviation vector only for 'NORM'
% for 'LOGNORM', 'EXPO'
% a = mean vector 
% b = standard deviation vector
% for 'UNIF', 'TRIANG', 'LOGUNIF'
% a = left 
% b = right boundary

mu=[0 0 0.0];
sigma=[1.0 1.0 1.0];
a =[-pi -pi -pi];
b =[pi pi pi];

%model='linearsum';
model='ishigami';
typesampling='Sobol';
%typesampling='Random';

% % % % %  Running the calculation
[S ST] = SOBOL_correlatedBD(k,N,typesampling,typedistr,mu,sigma,a,b,COR,model);

S1=S(end,:)
ST1=ST(end,:)
% 
% % % % % %  Write the results in .txt files
% %fid = fopen('linearsum_2_10_QMC.txt','w');
% 
% % % % %  keep only N=2^k values
b=log2(N);
x = zeros(b,1);
for a2 = 1 : b
    aa=2^a2;
    x(a2) = a2;
    Ect(a2,:)=S(aa,:);
    ETct(a2,:)=ST(aa,:);
   %fprintf(fid,'%i\t %i\t %i\t %i\n', x(a2)' , Ect(a2,:)');
end
figure
ax = gca;
% ax.LineStyleOrder = '-*|:|o';
% plot(x(:,1),Ect)
plot(x(:,1),Ect,x(:,1),ETct)
ylim([-0.1 1.1]);
ylabel('S, ST')
xlabel('log2(N)')
%plot(x,y1,'-ro',x,y2,'-.b')
legend('S1','S2','S3','ST1','ST2','ST3')
toc
% hold on; 
% plot(x(:,1),ETct)
% ylabel('ST')
% xlabel('N')
% legend('ST1','ST2','ST3')
% hold off
%fclose(fid);
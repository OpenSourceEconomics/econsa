function [x_required] = Tranformation_required_distribution(k,x_normal,typedistr,mu,sigma)

% k = n of inputs
% typedistr = type of distribution for input factors ('NORM', 'UNIF', 'EXPO', 'LOGNORM', 'TRIANG', 'LOGUNIF')
% for 'LOGNORM', 'EXPO'
% mu = mean vector 
% sigma= standard deviation vector
% for 'UNIF', 'TRIANG', 'LOGUNIF'
% parameters mu(i) and sigma(i) are treated here as a and b
% a = mu 
% b = sigma

% x_nomal = vector of correlated normal inputs
% x_required = vector of required distribution
%parameters for test model


% Created by S. Kucherenko, A. Klimenko
%Imperial College London, London, SW7 2AZ, UK
% Latest revision: 11 Jan, 2015


%Generation of two correlated vectors for a given distribution
for i=1:k
    if strcmp(typedistr(i),'UNIF'),
        %Compute the limits of the support of the random variable. 
        a = mu(i);
        b = sigma(i);
              
        x_required(i) = a + (b - a)*normcdf(x_normal(i),0,1);
          
    elseif strcmp(typedistr(i),'NORM'),
        x_required(i)=x_normal(i);
          
    elseif strcmp(typedistr(i),'EXPO'),
        x_required(i)=expinv(normcdf(x_normal(i),0,1),mu(i));
          
    elseif strcmp(typedistr(i),'LOGNORM'),
        CV=sigma(i)/mu(i);
        lambda=log(mu(i)/(sqrt(1+CV^2)));
        dzeta=sqrt(log(1+CV^2));
        
        x_required(i)=logninv(normcdf(x_normal(i),0,1),lambda,dzeta);
        
    elseif strcmp(typedistr1,'TRIANG'),
        %Compute the limits of the support of the random variable. 
        a = mu(i);
        b = sigma(i);
        
        x = normcdf(x_normal(i),0,1);
        
        x_required(i) = ((a + (b-a)*sqrt(x./2)).*(x >= 0).*(x < 0.5) + (b - (b-a)*sqrt((1-x)/2)).*(x >= 0.5).*(x <= 1));
        
    elseif strcmp(typedistr1,'LOGUNIF'),
        %parameters mu(i) and sigma(i) are treated here as a and b of the loguniform
        %disribution Y = ln(X), a <= X <= b
        a = mu(i);
        b = sigma(i);
        
        x_required(i) = a*(b./a).^x;
           
    end
end
return